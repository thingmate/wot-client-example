import { fromEventTarget, IObservable, IObserver, IPoint2D, let$$, map$$, merge, single } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  toStyleProperty,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { IStyleProperty } from '@lirx/dom/src/virtual-node/dom/nodes/static/element/style/style-property.type';
import {
  IconChevronRightComponent,
  IconCloseThickComponent,
  IconDeleteForeverOutlineComponent,
  IconPlusComponent,
  IconSwapHorizontalComponent,
} from '@lirx/mdi';
import { Store, InferMapArrayItemsMapFunction } from '@lirx/store';

// @ts-ignore
import html from './generic-node.component.html?raw';
// @ts-ignore
import style from './generic-node.component.scss?inline';

/*------------*/

// export function select$$<GIn, GOut>(
//   subscribe: IObservable<GIn>,
//   selectFunction: IMapFunction<GIn, GOut>,
// ): IObservable<GOut> {
//   return (emit: IObserver<GOut>): IUnsubscribe => {
//     let previousValue: GOut;
//     return subscribe((value: GIn): void => {
//       const _value: GOut = selectFunction(value);
//       if (_value !== previousValue) {
//         previousValue = _value;
//         emit(_value);
//       }
//     });
//   };
// }
//
// export function mapDistinctArrayItemsObservable<GIn extends object, GOut>(
//   subscribe: IObservable<readonly GIn[]>,
//   mapFunction: IMapFunction<GIn, GOut>,
// ): IObservable<readonly GOut[]> {
//   return (emit: IObserver<readonly GOut[]>): IUnsubscribe => {
//     const cache = new WeakMap<GIn, GOut>();
//
//     return subscribe((items: readonly GIn[]): void => {
//       emit(
//         items.map((item: GIn): GOut => {
//           if (!cache.has(item)) {
//             cache.set(item, mapFunction(item));
//           }
//           return cache.get(item)!;
//         }),
//       );
//     });
//   };
// }
//
// export function selectArrayItems$$<GValue, GIn extends object, GOut>(
//   subscribe: IObservable<GValue>,
//   selectFunction: IMapFunction<GValue, readonly GIn[]>,
//   mapItemsFunction: IMapFunction<GIn, GOut>,
// ): IObservable<readonly GOut[]> {
//   return mapDistinctArrayItemsObservable<GIn, GOut>(
//     select$$<GValue, readonly GIn[]>(subscribe, selectFunction),
//     mapItemsFunction,
//   );
// }

/*------------*/

export interface IConnectionPoint {
  readonly type: 'connection';
  readonly label: string;
  readonly removable?: boolean; // (default: false)
}

export interface IAddConnectionPoint {
  readonly type: 'add';
}

export type IConnectionPointEntry =
  | IConnectionPoint
  | IAddConnectionPoint
;

export interface IGenericNodeComponentConfig {
  readonly position: IPoint2D;
  readonly leftConnectionPoints: readonly IConnectionPointEntry[];
  readonly rightConnectionPoints: readonly IConnectionPointEntry[];
}

/*------------*/

// interface IReactiveConnectionPoint {
//   readonly type: 'connection';
//   readonly label$: IObservable<string>;
//   readonly removable$: IObservable<boolean>;
// }
//
// function connectionPointToReactiveConnectionPoint(
//   {
//     label,
//     removable = false,
//   }: IConnectionPoint,
// ): IReactiveConnectionPoint {
//   return {
//     type: 'connection',
//     label$: single(label),
//     removable$: single(removable),
//   };
// }
//
//
// interface IReactiveConnectionPoint {
//   readonly type: 'connection';
//   readonly label$: IObservable<string>;
//   readonly removable$: IObservable<boolean>;
// }
//
// function connectionPointToReactiveConnectionPoint(
//   {
//     label,
//     removable = false,
//   }: IConnectionPoint,
// ): IReactiveConnectionPoint {
//   return {
//     type: 'connection',
//     label$: single(label),
//     removable$: single(removable),
//   };
// }

/**
 * COMPONENT: 'app-generic-node'
 **/

interface IData {
  readonly leftConnectionPoints$: IObservable<readonly IConnectionPointEntry[]>;
  readonly $onClickExpandIcon: IObserver<any>;
}

interface ICreateGenericNodeComponentConfig {
  element: HTMLElement;
  inputs: [
    ['config', IGenericNodeComponentConfig],
  ],
  data: IData;
}

export const GenericNodeComponent = createComponent<ICreateGenericNodeComponentConfig>({
  name: 'app-generic-node',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      IconSwapHorizontalComponent,
      IconCloseThickComponent,
      IconPlusComponent,
      // IconDeleteOutlineComponent,
      IconDeleteForeverOutlineComponent,
      IconChevronRightComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['config'],
  ],
  init: (node: VirtualCustomElementNode<ICreateGenericNodeComponentConfig>): IData => {
    const configStore = Store.fromSource(node.inputs.getSource('config'));

    /* POSITION */
    const position$ = configStore
      .createSelector<IPoint2D>(_ => _.position)
      .get$();

    node.setReactiveStyleProperty('transform', map$$(position$, ({ x, y }): IStyleProperty => {
      return toStyleProperty(`translate(${x}px, ${y}px)`);
    }));

    /* LEFT CONNECTION POINTS */
    const leftConnectionPoints$ = configStore
      .createSelector<readonly IConnectionPointEntry[]>(_ => _.leftConnectionPoints)
      .get$();
      // .mapArrayItems$<IReactiveConnectionPoint>(connectionPointToReactiveConnectionPoint);


    // SET CONFIG
    configStore.$state({
      leftConnectionPoints: [
        {
          type: 'connection',
          label: 'in',
        },
      ],
      rightConnectionPoints: [
        {
          type: 'connection',
          label: 'out',
          removable: true,
        },
        {
          type: 'connection',
          label: 'out2',
        },
      ],
      position: {
        x: 0,
        y: 0,
      },
    });





    /*------*/

    // const [$active, active$, getActive] = let$$<boolean>(false);
    const [$collapsed, collapsed$, getCollapsed] = let$$<boolean>(true);

    const mouseDown$ = fromEventTarget<'mousedown', MouseEvent>(node.elementNode, 'mousedown');

    const localEvents$ = merge([
      mouseDown$,
      fromEventTarget<'wheel', WheelEvent>(node.elementNode, 'wheel'),
    ]);

    // node.onConnected$(mouseDown$)((event: Event): void => {
    //   $active(true);
    // });

    node.onConnected$(localEvents$)((event: Event): void => {
      // if (getActive()) {
      event.stopPropagation();
      // }
    });

    node.setReactiveClass('collapsed', collapsed$);

    const $onClickExpandIcon = () => {
      $collapsed(!getCollapsed());
    };

    return {
      leftConnectionPoints$,
      $onClickExpandIcon,
    };
  },
});
