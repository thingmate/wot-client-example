import { $log, functionI$$, IObservable } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { IClassNamesList } from '@lirx/dom/src/virtual-node/dom/nodes/reactive/element/class/class-names-list.type';
import { GenericNodeAddButtonComponent } from './components/add-button/generic-node-add-button.component';
import { GenericNodeConnectionPointComponent } from './components/connection-point/generic-node-connection-point.component';

// @ts-ignore
import html from './generic-node-side-items.component.html?raw';
// @ts-ignore
import style from './generic-node-side-items.component.scss?inline';
import { ISideItemsPosition } from './types/side-items-position.type';

export interface IConnectionPoint {
  readonly type: 'connection-point';
  readonly label: string;
  readonly removable?: boolean; // (default: false)
}

export interface IAddButton {
  readonly type: 'add-button';
}

export type IGenericNodeSideItem =
  | IConnectionPoint
  | IAddButton
  ;

/**
 * COMPONENT: 'app-generic-node-side-items'
 **/

interface IData {
  readonly items$: IObservable<readonly IGenericNodeSideItem[]>;
  readonly position$: IObservable<ISideItemsPosition>;
}

interface ICreateGenericNodeSideItemsComponentConfig {
  element: HTMLElement;
  inputs: [
    ['items', readonly IGenericNodeSideItem[]],
    ['position', ISideItemsPosition],
  ],
  data: IData;
}

export const GenericNodeSideItemsComponent = createComponent<ICreateGenericNodeSideItemsComponentConfig>({
  name: 'app-generic-node-side-items',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      GenericNodeConnectionPointComponent,
      GenericNodeAddButtonComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['items'],
    ['position'],
  ],
  init: (node: VirtualCustomElementNode<ICreateGenericNodeSideItemsComponentConfig>): IData => {
    const items$ = node.inputs.get$('items');
    const position$ = node.inputs.get$('position');

    const classNamesList$ = functionI$$(
      [position$],
      (position: ISideItemsPosition): IClassNamesList => {
        return new Set([
          `position-${position}`,
        ]);
      },
    );
    node.setReactiveClassNamesList(classNamesList$);

    return {
      items$,
      position$,
    };
  },
});
