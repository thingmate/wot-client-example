import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { IconPlusComponent } from '@lirx/mdi';

// @ts-ignore
import html from './generic-node-add-button.component.html?raw';
// @ts-ignore
import style from './generic-node-add-button.component.scss?inline';

/**
 * COMPONENT: 'app-generic-node-add-button'
 **/

interface IData {
  // readonly label$: IObservable<string>;
}

interface ICreateGenericNodeAddButtonComponentConfig {
  element: HTMLElement;
  inputs: [],
  data: IData;
}

export const GenericNodeAddButtonComponent = createComponent<ICreateGenericNodeAddButtonComponentConfig>({
  name: 'app-generic-node-add-button',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      IconPlusComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [],
  init: (node: VirtualCustomElementNode<ICreateGenericNodeAddButtonComponentConfig>): IData => {
    return {};
  },
});
