import { IObservable, IPoint2D, map$$ } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  toStyleProperty,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { IStyleProperty } from '@lirx/dom/src/virtual-node/dom/nodes/static/element/style/style-property.type';
import { Store } from '@lirx/store';
import { GenericNodeContainerComponent } from './components/container/generic-node-container.component';
import { GenericNodeSideItemsComponent, IGenericNodeSideItem } from './components/side-items/generic-node-side-items.component';

// @ts-ignore
import html from './generic-node.component.html?raw';
// @ts-ignore
import style from './generic-node.component.scss?inline';

export interface IGenericNodeComponentConfig {
  readonly position: IPoint2D;
  readonly leftSideItems: readonly IGenericNodeSideItem[];
}

/**
 * COMPONENT: 'app-generic-node'
 **/

interface IData {
  readonly leftSideItems$: IObservable<readonly IGenericNodeSideItem[]>;
}

interface ICreateGenericNodeComponentConfig {
  element: HTMLElement;
  inputs: [
    ['config', IGenericNodeComponentConfig],
  ],
  data: IData;
}

export const GenericNodeComponent = createComponent<ICreateGenericNodeComponentConfig>({
  name: 'app-generic-node',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      GenericNodeSideItemsComponent,
      GenericNodeContainerComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['config'],
  ],
  init: (node: VirtualCustomElementNode<ICreateGenericNodeComponentConfig>): IData => {
    const configStore = Store.fromSource(node.inputs.getSource('config'));

    /* POSITION */
    const position$ = configStore
      .createSelector<IPoint2D>(_ => _.position)
      .get$();

    node.setReactiveStyleProperty('transform', map$$(position$, ({ x, y }): IStyleProperty => {
      return toStyleProperty(`translate(${x}px, ${y}px)`);
    }));

    /* LEFT CONNECTION POINTS */
    const leftSideItems$ = configStore
      .createSelector<readonly IGenericNodeSideItem[]>(_ => _.leftSideItems)
      .get$();
    // .mapArrayItems$<IReactiveConnectionPoint>(connectionPointToReactiveConnectionPoint);

    // SET CONFIG
    configStore.$state({
      leftSideItems: [
        {
          type: 'connection-point',
          label: 'in',
        },
        {
          type: 'connection-point',
          label: 'in',
          removable: true,
        },
        {
          type: 'add-button',
        },
        {
          type: 'connection-point',
          label: 'in',
          removable: true,
        },
      ],
      // rightConnectionPoints: [
      //   {
      //     type: 'connection',
      //     label: 'out',
      //     removable: true,
      //   },
      //   {
      //     type: 'connection',
      //     label: 'out2',
      //   },
      // ],
      position: {
        x: 100,
        y: 100,
      },
    });

    return {
      leftSideItems$,
    };
  },
});
