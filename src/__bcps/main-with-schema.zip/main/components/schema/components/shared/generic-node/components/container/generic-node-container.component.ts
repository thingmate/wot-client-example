import { fromEventTarget, IObserver, let$$, merge } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { IconChevronRightComponent, IconDeleteForeverOutlineComponent, IconSwapHorizontalComponent } from '@lirx/mdi';

// @ts-ignore
import html from './generic-node-container.component.html?raw';
// @ts-ignore
import style from './generic-node-container.component.scss?inline';

/**
 * COMPONENT: 'app-generic-node-container'
 **/

interface IData {
  readonly $onClickExpandIcon: IObserver<any>;
}

interface ICreateGenericNodeContainerComponentConfig {
  element: HTMLElement;
  inputs: [],
  data: IData;
}

export const GenericNodeContainerComponent = createComponent<ICreateGenericNodeContainerComponentConfig>({
  name: 'app-generic-node-container',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      IconSwapHorizontalComponent,
      IconDeleteForeverOutlineComponent,
      IconChevronRightComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [],
  init: (node: VirtualCustomElementNode<ICreateGenericNodeContainerComponentConfig>): IData => {
    // const [$active, active$, getActive] = let$$<boolean>(false);
    const [$collapsed, collapsed$, getCollapsed] = let$$<boolean>(true);

    const mouseDown$ = fromEventTarget<'mousedown', MouseEvent>(node.elementNode, 'mousedown');

    const localEvents$ = merge([
      mouseDown$,
      fromEventTarget<'wheel', WheelEvent>(node.elementNode, 'wheel'),
    ]);

    // node.onConnected$(mouseDown$)((event: Event): void => {
    //   $active(true);
    // });

    node.onConnected$(localEvents$)((event: Event): void => {
      // if (getActive()) {
      event.stopPropagation();
      // }
    });

    node.setReactiveClass('collapsed', collapsed$);

    const $onClickExpandIcon = () => {
      $collapsed(!getCollapsed());
    };

    return {
      $onClickExpandIcon,
    };
  },
});
