import {
  mat4,
  mat4_copy,
  mat4_create,
  mat4_from_scale_origin,
  mat4_from_translation,
  mat4_invert,
  mat4_multiply,
  readonly_mat4,
  readonly_vec3,
  vec3,
  vec3_copy,
  vec3_create,
  vec3_set,
  vec3_subtract,
  vec3_transform_mat4,
  vec3_zero,
} from '@lifaon/math';
import {
  createDraggableObservable,
  fromEventTarget,
  IDraggableObservableNotifications,
  IObservable,
  IObserver,
  IUnsubscribe,
} from '@lirx/core';

export function createFreeCamera2D(
  container: Element,
  initialViewMatrix: readonly_mat4 = mat4_create(),
): IObservable<readonly_mat4> {
  return (emit: IObserver<readonly_mat4>): IUnsubscribe => {
    const transformMatrix: mat4 = mat4_create();
    const viewMatrix: mat4 = mat4_copy(mat4_create(), initialViewMatrix);

    const dragDeltaVector: vec3 = vec3_create();
    const dragDeltaLastVector: vec3 = vec3_create();
    const dragTranslateVector: vec3 = vec3_create();

    const transform = (transformMatrix: readonly_mat4): void => {
      mat4_multiply(viewMatrix, transformMatrix, viewMatrix);
      emit(viewMatrix);
    };

    // let dragging: boolean = false;

    const unsubscribeDraggable = createDraggableObservable(container)((notification: IDraggableObservableNotifications) => {
      switch (notification.name) {
        case 'drag-start':
          vec3_zero(dragDeltaLastVector);
          break;
        case 'drag-move': {
          // dragging ||= (notification.value.delta.x !== 0) && (notification.value.delta.y !== 0);
          vec3_set(dragDeltaVector, notification.value.delta.x, notification.value.delta.y, 0);
          vec3_subtract(dragTranslateVector, dragDeltaVector, dragDeltaLastVector);
          vec3_copy(dragDeltaLastVector, dragDeltaVector);

          transform(mat4_from_translation(transformMatrix, dragTranslateVector));
          break;
        }
        // case 'drag-end':
        //   dragging = false;
        //   break;
      }
    });

    // const scaling: vec3 = mat4_getScaling(vec3_create(), viewMatrix);
    // const scalingStep: vec3 = vec3_fromValues(0.1, 0.1, 0.1);
    const scalingStep: number = 1.001;
    const scalingVector: vec3 = vec3_create();
    const positionVector: vec3 = vec3_create();

    const getPointerPosition = (out: vec3, event: MouseEvent): vec3 => {
      const rect = container.getBoundingClientRect();
      out[0] = event.clientX - rect.x;
      out[1] = event.clientY - rect.y;
      return out;
    };

    const unsubscribeWheel = fromEventTarget<'wheel', WheelEvent>(container, 'wheel')((event: WheelEvent) => {
      event.preventDefault();

      getPointerPosition(positionVector, event);

      const scaling: number = (event.deltaY <= 0)
        ? (scalingStep ** -(event.deltaY))
        : (1 / (scalingStep ** event.deltaY));

      vec3_set(scalingVector, scaling, scaling, 1);
      mat4_from_scale_origin(transformMatrix, scalingVector, positionVector);

      transform(transformMatrix);
    });

    emit(viewMatrix);

    return (): void => {
      unsubscribeDraggable();
      unsubscribeWheel();
    };
  };
}
