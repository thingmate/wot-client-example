import { mat4_to_css_matrix } from '@lifaon/math';
import { empty, IObservable, map$$ } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import { IntervalNodeComponent } from './components/node/interval-node.component';
import { createFreeCamera2D } from './free-camera-2d';

// @ts-ignore
import html from './schema.component.html?raw';
// @ts-ignore
import style from './schema.component.scss?inline';

/**
 * COMPONENT: 'app-schema'
 **/

interface IData {
  readonly transformStyle$: IObservable<string>;
}

interface ISchemaComponentConfig {
  element: HTMLElement;
  data: IData;
}

export const SchemaComponent = createComponent<ISchemaComponentConfig>({
  name: 'app-schema',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      IntervalNodeComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  init: (node: VirtualCustomElementNode<ISchemaComponentConfig>): IData => {
    const freeCamera$ = createFreeCamera2D(node.elementNode);

    const transformStyle$ = map$$(freeCamera$, mat4_to_css_matrix);
    // const transformStyle$ = empty();

    return {
      transformStyle$,
    };
  },
});
