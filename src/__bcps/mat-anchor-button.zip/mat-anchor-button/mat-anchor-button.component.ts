import { IObservable, mapDistinct$$ } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent, VirtualCustomElementNode } from '@lirx/dom';

// @ts-ignore
import html from './mat-anchor-button.component.html?raw';
// @ts-ignore
import style from './mat-anchor-button.component.scss?inline';

/* CONFIG */

export interface IMatAnchorButtonConfig {
  href?: string;

}

/**
 * COMPONENT: 'mat-anchor-button'
 **/


type IMatAnchorButtonMode = 'anchor' | 'button';

interface IData {
  readonly mode$: IObservable<IMatAnchorButtonMode>;
}

interface IMatAnchorButtonComponentConfig {
  element: HTMLElement;
  inputs: [
    ['config', IMatAnchorButtonConfig],
  ],
  data: IData;
}

export const MatAnchorButtonComponent = createComponent<IMatAnchorButtonComponentConfig>({
  name: 'mat-anchor-button',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['config'],
  ],
  init: (node: VirtualCustomElementNode<IMatAnchorButtonComponentConfig>): IData => {
    const config$ = node.inputs.get$('config');

    const mode$ = mapDistinct$$(config$, (config: IMatAnchorButtonConfig): IMatAnchorButtonMode => {
      return config.href
        ? 'anchor'
        : 'button';
    });

    return {
      mode$,
    };
  },
});
