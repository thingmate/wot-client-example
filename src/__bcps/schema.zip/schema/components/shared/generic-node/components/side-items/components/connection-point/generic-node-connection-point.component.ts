import { functionI$$, IObservable } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { IClassNamesList } from '@lirx/dom/src/virtual-node/dom/nodes/reactive/element/class/class-names-list.type';
import { IconCloseThickComponent } from '@lirx/mdi';
import { ISideItemsPosition } from '../../types/side-items-position.type';

// @ts-ignore
import html from './generic-node-connection-point.component.html?raw';
// @ts-ignore
import style from './generic-node-connection-point.component.scss?inline';

/**
 * COMPONENT: 'app-generic-node-connection-point'
 **/

interface IData {
  readonly label$: IObservable<string>;
}

interface ICreateGenericNodeConnectionPointComponentConfig {
  element: HTMLElement;
  inputs: [
    ['label', string],
    ['removable', boolean],
    ['position', ISideItemsPosition],
  ],
  data: IData;
}

export const GenericNodeConnectionPointComponent = createComponent<ICreateGenericNodeConnectionPointComponentConfig>({
  name: 'app-generic-node-connection-point',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      IconCloseThickComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['label'],
    ['removable'],
    ['position'],
  ],
  init: (node: VirtualCustomElementNode<ICreateGenericNodeConnectionPointComponentConfig>): IData => {
    const label$ = node.inputs.get$('label');
    const removable$ = node.inputs.get$('removable');
    const position$ = node.inputs.get$('position');

    node.setReactiveClass('removable', removable$);

    const classNamesList$ = functionI$$(
      [position$],
      (position: ISideItemsPosition): IClassNamesList => {
        return new Set([
          `position-${position}`,
        ]);
      },
    );
    node.setReactiveClassNamesList(classNamesList$);

    return {
      label$,
    };
  },
});
