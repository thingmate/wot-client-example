import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import { GenericNodeComponent } from '../shared/generic-node/generic-node.component';

// @ts-ignore
import html from './interval-node.component.html?raw';
// @ts-ignore
import style from './interval-node.component.scss?inline';

/**
 * COMPONENT: 'app-interval-node'
 **/

interface IData {
  // readonly $onClickExpandIcon: IObserver<any>;
}

interface IIntervalNodeComponentConfig {
  element: HTMLElement;
  data: IData;
}

export const IntervalNodeComponent = createComponent<IIntervalNodeComponentConfig>({
  name: 'app-interval-node',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      GenericNodeComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  init: (node: VirtualCustomElementNode<IIntervalNodeComponentConfig>): IData => {
    return {};
  },
});
