import { Abortable, AsyncTask, asyncTimeout, IAsyncTaskInput } from '@lirx/async-task';
import { IMapFilterMapFunctionReturn, IObservable, map$$, MAP_FILTER_DISCARD, mapFilter$$ } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import { MAT_BUTTON_MODIFIER, MAT_ICON_BUTTON_MODIFIER } from '@lirx/dom-material';
import { IconChevronLeftComponent, IconChevronRightComponent, IconPageFirstComponent, IconPageLastComponent } from '@lirx/mdi';
import { MatLinkComponent } from '../mat-link/mat-link.component';
import { buildMatPaginationConfig } from './functions/build-mat-pagination-config';
import {
  IMatPaginationButtonConfig,
  MatPaginationButtonComponent,
} from './components/mat-pagination-button/mat-pagination-button.component';

// @ts-ignore
import html from './mat-pagination.component.html?raw';
// @ts-ignore
import style from './mat-pagination.component.scss?inline';

/** TYPES **/

export interface IMatPaginationButton extends IMatPaginationButtonConfig {
}

export interface IMatPaginationPage extends IMatPaginationButton {
  readonly label: string;
  readonly selected: boolean;
}

export interface IMatPaginationConfig {
  readonly pages: readonly IMatPaginationPage[];

  readonly disabled?: boolean;
  readonly firstButton?: IMatPaginationButton;
  readonly prevButton?: IMatPaginationButton;
  readonly nextButton?: IMatPaginationButton;
  readonly lastButton?: IMatPaginationButton;
}

/**
 * COMPONENT: 'mat-pagination'
 **/

interface IData {
  readonly firstButtonVisible$: IObservable<boolean>;
  readonly firstButton$: IObservable<IMatPaginationButton>;
  readonly prevButtonVisible$: IObservable<boolean>;
  readonly prevButton$: IObservable<IMatPaginationButton>;

  readonly pages$: IObservable<readonly IMatPaginationPage[]>;

  readonly nextButtonVisible$: IObservable<boolean>;
  readonly nextButton$: IObservable<IMatPaginationButton>;
  readonly lastButtonVisible$: IObservable<boolean>;
  readonly lastButton$: IObservable<IMatPaginationButton>;
}

interface IMatPaginationComponentConfig {
  element: HTMLElement;
  inputs: [
    ['config', IMatPaginationConfig],
  ];
  data: IData;
}

export const MatPaginationComponent = createComponent<IMatPaginationComponentConfig>({
  name: 'mat-pagination',
  extends: 'nav',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatPaginationButtonComponent,
      MatLinkComponent,
      IconPageFirstComponent,
      IconChevronLeftComponent,
      IconChevronRightComponent,
      IconPageLastComponent,
    ],
    modifiers: [
      MAT_BUTTON_MODIFIER,
      MAT_ICON_BUTTON_MODIFIER,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['config'],
  ],
  init: (node: VirtualCustomElementNode<IMatPaginationComponentConfig>): IData => {
    node.setAttribute('aria-label', 'pagination navigation');

    const config$ = node.inputs.get$('config');

    const _config$ = buildMatPaginationConfig({
      count: 10,
      selectedPageIndex: 5,
      firstButtonVisible: true,
      lastButtonVisible: true,
      onPageChange: (index: number) => {
        console.log('on page', index);
        return asyncTimeout(1000, Abortable.never).toPromise();
      },
      // generatePage: (index: number) => {
      //   return {
      //     href: `/goto/${index}`,
      //     label: String(index + 1),
      //   };
      // },
    });

    _config$(node.inputs.$set('config'));

    /* DISABLED */

    const disabled$ = map$$(config$, (config: IMatPaginationConfig): boolean => {
      return config.disabled ?? false;
    });

    node.setReactiveClass('disabled', disabled$);

    /* FIRST BUTTON */

    const firstButtonVisible$ = map$$(config$, (config: IMatPaginationConfig): boolean => {
      return config.firstButton !== void 0;
    });

    const firstButton$ = mapFilter$$(config$, (config: IMatPaginationConfig): IMapFilterMapFunctionReturn<IMatPaginationButton> => {
      return (config.firstButton === void 0)
        ? MAP_FILTER_DISCARD
        : config.firstButton;
    });

    /* PREV BUTTON */

    const prevButtonVisible$ = map$$(config$, (config: IMatPaginationConfig): boolean => {
      return config.prevButton !== void 0;
    });

    const prevButton$ = mapFilter$$(config$, (config: IMatPaginationConfig): IMapFilterMapFunctionReturn<IMatPaginationButton> => {
      return (config.prevButton === void 0)
        ? MAP_FILTER_DISCARD
        : config.prevButton;
    });

    /* PAGES */

    const pages$ = map$$(config$, (config: IMatPaginationConfig): readonly IMatPaginationPage[] => {
      return config.pages;
    });

    /* NEXT BUTTON */

    const nextButtonVisible$ = map$$(config$, (config: IMatPaginationConfig): boolean => {
      return config.nextButton !== void 0;
    });

    const nextButton$ = mapFilter$$(config$, (config: IMatPaginationConfig): IMapFilterMapFunctionReturn<IMatPaginationButton> => {
      return (config.nextButton === void 0)
        ? MAP_FILTER_DISCARD
        : config.nextButton;
    });

    /* LAST BUTTON */

    const lastButtonVisible$ = map$$(config$, (config: IMatPaginationConfig): boolean => {
      return config.lastButton !== void 0;
    });

    const lastButton$ = mapFilter$$(config$, (config: IMatPaginationConfig): IMapFilterMapFunctionReturn<IMatPaginationButton> => {
      return (config.lastButton === void 0)
        ? MAP_FILTER_DISCARD
        : config.lastButton;
    });

    return {
      firstButtonVisible$,
      firstButton$,
      prevButtonVisible$,
      prevButton$,
      pages$,
      nextButtonVisible$,
      nextButton$,
      lastButtonVisible$,
      lastButton$,
    };
  },
});

/*------------------*/

export interface INavigateToPageFunction {
  (
    index: number,
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}

export class MatPaginationNavigation {

  #navigateToPage: INavigateToPageFunction;
  #queue: AsyncTask<void>;

  constructor(
    navigateToPage: INavigateToPageFunction,
  ) {
    this.#navigateToPage = navigateToPage;
    this.#queue = AsyncTask.void(Abortable.never);
  }

  navigateToPage(
    abortable: Abortable,
  ): AsyncTask<void> {

  }

  navigateToFirstPage(
    abortable: Abortable,
  ): AsyncTask<void> {

  }
}
