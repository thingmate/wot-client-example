import { debounceFrame$$, IObservable, let$$ } from '@lirx/core';
import {
  buildMatPaginationPages,
  DEFAULT_BUILD_MAT_PAGINATION_PAGES_GENERATE_PAGE_FUNCTION,
  IBuildMatPaginationPagesGeneratePageFunctionResult,
  IBuildMatPaginationPagesOptions,
} from './build-mat-pagination-pages';
import { generateMatPaginationFirstPageAriaLabel } from './aria-label/generate-mat-pagination-first-page-aria-label';
import { generateMatPaginationLastPageAriaLabel } from './aria-label/generate-mat-pagination-last-page-aria-label';
import { generateMatPaginationNextPageAriaLabel } from './aria-label/generate-mat-pagination-next-page-aria-label';
import { generateMatPaginationPrevPageAriaLabel } from './aria-label/generate-mat-pagination-prev-page-aria-label';
import { IMatPaginationButton, IMatPaginationConfig, IMatPaginationPage } from '../mat-pagination.component';

export interface IBuildMatPaginationPagesOnPageChangeFunction {
  (
    index: number,
  ): Promise<void> | void;
}

export interface IBuildMatPaginationConfigOptions extends IBuildMatPaginationPagesOptions {
  onPageChange?: IBuildMatPaginationPagesOnPageChangeFunction;
  firstButtonVisible?: boolean;
  prevButtonVisible?: boolean;
  nextButtonVisible?: boolean;
  lastButtonVisible?: boolean;
}

export function buildMatPaginationConfig(
  {
    onPageChange,
    count,
    selectedPageIndex,
    firstButtonVisible = false,
    prevButtonVisible = true,
    nextButtonVisible = true,
    lastButtonVisible = false,
    generatePage = DEFAULT_BUILD_MAT_PAGINATION_PAGES_GENERATE_PAGE_FUNCTION,
    ...options
  }: IBuildMatPaginationConfigOptions,
): IObservable<IMatPaginationConfig> {
  const [$config, config$, getConfig] = let$$<IMatPaginationConfig>();

  let selectPromise: Promise<void> = Promise.resolve();

  const select = (
    index: number,
    force: boolean = false,
  ): Promise<void> => {
    const newSelectedPageIndex: number = Math.max(0, Math.min(count - 1, index));
    if (
      (newSelectedPageIndex !== selectedPageIndex)
      || force
    ) {
      selectPromise = selectPromise
        .then((): Promise<void> | void => {
          if (onPageChange !== void 0) {
            const result = onPageChange(newSelectedPageIndex);
            if (result !== void 0) {
              const config: IMatPaginationConfig = getConfig();
              if (config !== void 0) {
                $config({
                  ...config,
                  disabled: true,
                });
              }

              return result;
            }
          }
        })
        .then(() => {
          selectedPageIndex = newSelectedPageIndex;
          update();
        });

    }

    return selectPromise;
  };

  const createNavigationButton = (
    index: number,
    visible: boolean,
    ariaLabel: string,
  ): IMatPaginationButton | undefined => {
    if (visible) {
      if (selectedPageIndex === index) {
        return {
          disabled: true,
        };
      } else {
        const {
          disabled = false,
          onClick,
          ...page
        }: IBuildMatPaginationPagesGeneratePageFunctionResult = generatePage(index, false);

        return {
          ariaLabel,
          ...page,
          disabled: (count === 0) || disabled,
          onClick: (event: MouseEvent): void => {
            if (onClick !== void 0) {
              onClick(event);
            }
            select(index);
          },
        };
      }
    } else {
      return void 0;
    }
  };

  const update = (): void => {
    const pages: IMatPaginationPage[] = buildMatPaginationPages({
      count,
      selectedPageIndex,
      generatePage: (index: number, selected: boolean): IBuildMatPaginationPagesGeneratePageFunctionResult => {
        const {
          onClick,
          ...page
        }: IBuildMatPaginationPagesGeneratePageFunctionResult = generatePage(index, selected);

        return {
          ...page,
          onClick: (event: MouseEvent): void => {
            if (onClick !== void 0) {
              onClick(event);
            }
            select(index);
          },
        };
      },
      ...options,
    });

    const firstButton: IMatPaginationButton | undefined = createNavigationButton(
      0,
      firstButtonVisible,
      generateMatPaginationFirstPageAriaLabel(),
    );

    const prevButton: IMatPaginationButton | undefined = createNavigationButton(
      Math.max(0, selectedPageIndex - 1),
      prevButtonVisible,
      generateMatPaginationPrevPageAriaLabel(),
    );

    const nextButton: IMatPaginationButton | undefined = createNavigationButton(
      Math.min(count - 1, selectedPageIndex + 1),
      nextButtonVisible,
      generateMatPaginationNextPageAriaLabel(),
    );

    const lastButton: IMatPaginationButton | undefined = createNavigationButton(
      Math.max(0, count - 1),
      lastButtonVisible,
      generateMatPaginationLastPageAriaLabel(),
    );

    const config: IMatPaginationConfig = {
      disabled: false,
      pages,
      firstButton,
      prevButton,
      nextButton,
      lastButton,
    };

    $config(config);
  };

  select(selectedPageIndex, true);

  return debounceFrame$$(config$);
}
