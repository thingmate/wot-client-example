import { generateMatPaginationPageAriaLabel } from './aria-label/generate-mat-pagination-page-aria-label';
import { generateMatPaginationSelectedPageAriaLabel } from './aria-label/generate-mat-pagination-selected-page-aria-label';
import { IMatPaginationPage } from '../mat-pagination.component';

export interface IBuildMatPaginationPagesGeneratePageFunctionResult extends //
  Omit<IMatPaginationPage, 'selected' | 'disabled'>,
  Partial<Pick<IMatPaginationPage, 'disabled'>>
//
{

}

export interface IBuildMatPaginationPagesGeneratePageFunction {
  (
    index: number,
    selected: boolean,
  ): IBuildMatPaginationPagesGeneratePageFunctionResult;
}

export const DEFAULT_BUILD_MAT_PAGINATION_PAGES_GENERATE_PAGE_FUNCTION = (
  index: number,
): IBuildMatPaginationPagesGeneratePageFunctionResult => {
  return {
    label: String(index + 1),
  };
};

export interface IBuildMatPaginationPagesOptions {
  count: number;
  selectedPageIndex: number;
  generatePage?: IBuildMatPaginationPagesGeneratePageFunction;
  siblingCount?: number,
  boundaryCount?: number,
}

export function buildMatPaginationPages(
  {
    count,
    selectedPageIndex,
    generatePage = DEFAULT_BUILD_MAT_PAGINATION_PAGES_GENERATE_PAGE_FUNCTION,
    siblingCount = 1,
    boundaryCount = 1,
  }: IBuildMatPaginationPagesOptions,
): IMatPaginationPage[] {
  const pages: IMatPaginationPage[] = [];

  const _generatePage = (
    index: number,
  ): IMatPaginationPage => {
    const selected: boolean = (index === selectedPageIndex);

    const page: IBuildMatPaginationPagesGeneratePageFunctionResult = generatePage(index, selected);

    const ariaLabel: string = selected
      ? generateMatPaginationSelectedPageAriaLabel(page.label)
      : generateMatPaginationPageAriaLabel(page.label);

    return (index === selectedPageIndex)
      ? {
        ariaLabel,
        ...page,
        disabled: true,
        selected: true,
      }
      : {
        ariaLabel,
        disabled: false,
        ...page,
        selected: false,
      };
  };

  const generatePages = (
    start: number,
    end: number,
  ): void => {
    for (let i = start; i < end; i++) {
      pages.push(_generatePage(i));
    }
  };

  const generateEllipsisPage = (): IMatPaginationPage => {
    return {
      label: '…',
      selected: false,
      disabled: true,
    };
  };

  // [boundaryCount, 1 (first ellipsis), siblingCount, 1 (selected), siblingCount, 1 (last ellipsis), boundaryCount]

  const a: number = boundaryCount + 1 + siblingCount;

  if (count <= (a + 1 + a)) {
    generatePages(0, count);
  } else {
    if (selectedPageIndex > a) { // requires first ellipsis
      generatePages(0, boundaryCount);

      pages.push(generateEllipsisPage());

      if (selectedPageIndex < (count - a)) { // requires last ellipsis
        generatePages(selectedPageIndex - siblingCount, selectedPageIndex + 1 /* selected */ + siblingCount);
        pages.push(generateEllipsisPage());
        generatePages(count - boundaryCount, count);
      } else {
        generatePages(count - (siblingCount + 1 /*selected*/ + siblingCount + 1 /*ellipsis*/ + boundaryCount), count);
      }
    } else { // requires last ellipsis
      generatePages(0, boundaryCount + 1 /*ellipsis*/ + siblingCount + 1 /* selected */ + siblingCount);
      pages.push(generateEllipsisPage());
      generatePages(count - boundaryCount, count);
    }
  }

  return pages;
}
