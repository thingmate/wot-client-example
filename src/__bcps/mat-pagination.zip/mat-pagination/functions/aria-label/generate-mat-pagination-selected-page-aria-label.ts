export function generateMatPaginationSelectedPageAriaLabel(
  label: string,
): string {
  return `Page ${label}`;
}
