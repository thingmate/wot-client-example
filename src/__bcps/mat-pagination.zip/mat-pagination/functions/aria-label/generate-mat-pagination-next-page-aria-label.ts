export function generateMatPaginationNextPageAriaLabel(): string {
  return `Go to next page`;
}
