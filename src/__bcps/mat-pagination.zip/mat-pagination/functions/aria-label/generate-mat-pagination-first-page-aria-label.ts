export function generateMatPaginationFirstPageAriaLabel(): string {
  return `Go to first page`;
}

