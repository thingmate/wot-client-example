export function generateMatPaginationPrevPageAriaLabel(): string {
  return `Go to previous page`;
}
