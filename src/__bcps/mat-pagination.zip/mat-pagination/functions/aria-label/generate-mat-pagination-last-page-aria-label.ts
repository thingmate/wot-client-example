export function generateMatPaginationLastPageAriaLabel(): string {
  return `Go to last page`;
}
