export function generateMatPaginationPageAriaLabel(
  label: string,
): string {
  return `Go to page ${label}`;
}
