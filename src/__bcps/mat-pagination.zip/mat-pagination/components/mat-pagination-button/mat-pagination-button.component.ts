import { IObservable, IObserver, map$$, mapObservableToObserver, or$$ } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import { MAT_BUTTON_MODIFIER } from '@lirx/dom-material';
import { MatLinkComponent } from '../../../mat-link/mat-link.component';

// @ts-ignore
import html from './mat-pagination-button.component.html?raw';
// @ts-ignore
import style from './mat-pagination-button.component.scss?inline';

/** TYPES **/

export interface IMatPaginationButtonOnClickFunction {
  (
    event: MouseEvent,
  ): void;
}

export interface IMatPaginationButtonConfig {
  readonly selected?: boolean;
  readonly disabled?: boolean;
  readonly href?: string;
  readonly ariaLabel?: string;
  readonly onClick?: IMatPaginationButtonOnClickFunction;
}

/**
 * COMPONENT: 'mat-pagination-button'
 **/

interface IData {
  readonly disabled$: IObservable<boolean>;
  readonly href$: IObservable<string>;
  readonly ariaLabel$: IObservable<string>;
  readonly $onClick: IObserver<MouseEvent>;
}

interface IMatPaginationButtonComponentConfig {
  element: HTMLElement;
  inputs: [
    ['config', IMatPaginationButtonConfig],
  ];
  data: IData;
}

export const MatPaginationButtonComponent = createComponent<IMatPaginationButtonComponentConfig>({
  name: 'mat-pagination-button',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatLinkComponent,
    ],
    modifiers: [
      MAT_BUTTON_MODIFIER,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['config'],
  ],
  init: (node: VirtualCustomElementNode<IMatPaginationButtonComponentConfig>): IData => {
    const config$ = node.inputs.get$('config');

    /* SELECTED */

    const selected$ = map$$(config$, (config: IMatPaginationButtonConfig): boolean => {
      return config.selected ?? false;
    });

    node.setReactiveClass('mat-selected', selected$);

    /* DISABLED */

    const _disabled$ = map$$(config$, (config: IMatPaginationButtonConfig): boolean => {
      return config.disabled ?? false;
    });

    const disabled$ = or$$(selected$, _disabled$);

    /* HREF */

    const href$ = map$$(config$, (config: IMatPaginationButtonConfig): string => {
      return config.href ?? '';
    });

    /* ARIA-LABEL */

    const ariaLabel$ = map$$(config$, (config: IMatPaginationButtonConfig): string => {
      return config.ariaLabel ?? '';
    });

    /* ONCLICK */

    const onClick$ = map$$(config$, (config: IMatPaginationButtonConfig): IMatPaginationButtonOnClickFunction => {
      return config.onClick ?? (() => {
      });
    });

    const [$onClick] = mapObservableToObserver(
      node.onConnected$(onClick$),
      (onClick: IMatPaginationButtonOnClickFunction): IObserver<MouseEvent> => {
        return onClick;
      },
    );

    return {
      disabled$,
      href$,
      ariaLabel$,
      $onClick,
    };
  },
});

