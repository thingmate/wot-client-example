import { Abortable, AsyncTask } from '@lirx/async-task';
import { empty, IObservable, IObserver, let$$, map$$ } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import { MatDualRingLoaderComponent } from '@lirx/dom-material';
import { IconPowerComponent } from '@lirx/mdi';
import { sleep } from '@lirx/promise';
import {
  createConsumedThingFromWoT,
  fetchTD,
  IConsumedThing, IExposedThing,
  ISmartPlugConfig, ISmartPlugConsumedThing,
  ISmartPlugState,
  IWoT,
} from '@thingmate/wot-scripting-api';
import { ThingDescription } from 'wot-typescript-definitions';
import { runWoTContext } from '../../../../../../../../../../../wot/run-wot-context';
import { WidgetIconToggleButtonComponent } from '../../widget-icon-toggle-button.component';

// @ts-ignore
import html from './widget-icon-toggle-button-1.component.html?raw';
// @ts-ignore
import style from './widget-icon-toggle-button-1.component.scss?inline';

/**
 * COMPONENT: 'app-widget-icon-toggle-button-1'
 **/

interface IData {
  readonly active$: IObservable<boolean>;
  readonly $onClickOnOffToggleButton: IObserver<any>;
}

interface IWidgetIconToggleButton1ComponentConfig {
  element: HTMLElement;
  data: IData;
}

export type ISmartPlug = IConsumedThing<ISmartPlugConfig>;

export const WidgetIconToggleButton1Component = createComponent<IWidgetIconToggleButton1ComponentConfig>({
  name: 'app-widget-icon-toggle-button-1',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      WidgetIconToggleButtonComponent,
      IconPowerComponent,
      MatDualRingLoaderComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  init: (node: VirtualCustomElementNode<IWidgetIconToggleButton1ComponentConfig>): IData => {
    const consumedThing$ = empty<ISmartPlugConsumedThing>();
    const [$loading, loading$] = let$$<boolean>(false);
    const [$state, state$, getState] = let$$<ISmartPlugState>();

    let thing: ISmartPlug;

    const getConsumedThing = () => {
      return runWoTContext((WoT: IWoT) => {
        return fetchTD('http://localhost:8080/19011048496979251h0234298f149604', void 0, Abortable.never)
          .successful((td: ThingDescription, abortable: Abortable): AsyncTask<ISmartPlug> => {
            return createConsumedThingFromWoT(WoT, td, { abortable });
          })
          .toPromise();
      });
    };

    getConsumedThing()
      .then((_thing: ISmartPlug): void => {
        thing = _thing;

        const propertyState = thing.getProperty('state');

        const loop = async () => {
          while (true) {
            $state(await propertyState.read());
            await sleep(1000);
          }
        };

        loop();
      });

    const active$ = map$$(state$, (state: ISmartPlugState): boolean => {
      return state === 'on';
    });

    const $onClickOnOffToggleButton = () => {
      if (thing !== void 0) {
        const propertyState = thing.getProperty('state');
        $loading(true);
        const _state = (getState() === 'on') ? 'off' : 'on';
        $state(_state);
        propertyState.write(_state)
          .finally(() => {
            $loading(false);
          });
      }
      // $state(!getState());
    };

    node.setReactiveClass('loading', loading$);

    return {
      active$,
      $onClickOnOffToggleButton,
    };
  },
});
