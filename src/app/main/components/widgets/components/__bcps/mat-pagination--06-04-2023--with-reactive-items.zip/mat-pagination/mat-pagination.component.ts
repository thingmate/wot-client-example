import { $$distinct, IObservable, IObserver } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  IVirtualReactiveForLoopNodeOptionsTrackByFunction, trackByIdentity,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { MAT_BUTTON_MODIFIER, MAT_ICON_BUTTON_MODIFIER } from '@lirx/dom-material';
import { IconChevronLeftComponent, IconChevronRightComponent, IconPageFirstComponent, IconPageLastComponent } from '@lirx/mdi';
import { IReactiveMatPaginationItem } from './types/reactive-mat-pagination-item.type';

// @ts-ignore
import html from './mat-pagination.component.html?raw';
// @ts-ignore
import style from './mat-pagination.component.scss?inline';

/**
 * COMPONENT: 'mat-pagination'
 **/

interface IData {
  readonly items$: IObservable<readonly IReactiveMatPaginationItem[]>;
  readonly trackBy: IVirtualReactiveForLoopNodeOptionsTrackByFunction<IReactiveMatPaginationItem>;
  readonly $selectedPageIndex: IObserver<number>;
}

interface IMatPaginationComponentConfig {
  element: HTMLElement;
  inputs: [
    ['items', readonly IReactiveMatPaginationItem[]],
    ['disabled', boolean],
  ];
  outputs: [
    ['selectedPageIndex', number],
  ];
  data: IData;
}

export const MatPaginationComponent = createComponent<IMatPaginationComponentConfig>({
  name: 'mat-pagination',
  extends: 'nav',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      IconPageFirstComponent,
      IconChevronLeftComponent,
      IconChevronRightComponent,
      IconPageLastComponent,
    ],
    modifiers: [
      MAT_BUTTON_MODIFIER,
      MAT_ICON_BUTTON_MODIFIER,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['items'],
    ['disabled', false],
  ],
  outputs: [
    'selectedPageIndex',
  ],
  init: (node: VirtualCustomElementNode<IMatPaginationComponentConfig>): IData => {
    node.setAttribute('aria-label', 'pagination navigation');

    /* ITEMS */

    const items$ = node.inputs.get$('items');

    const trackBy = trackByIdentity;

    /* DISABLED */

    const disabled$ = node.inputs.get$('disabled');

    node.setReactiveClass('mat-disabled', disabled$);

    /* PAGE INDEX */

    const $selectedPageIndex = $$distinct(node.outputs.$set('selectedPageIndex'));

    return {
      items$,
      trackBy,
      $selectedPageIndex,
    };
  },
});
