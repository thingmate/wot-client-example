import {
  $$distinct,
  $$map,
  IObservable,
  IObserver,
  let$$,
  map$$$,
  mapObservableToObserver,
  pipe$$,
  shareRL$$$,
  switchMap$$,
} from '@lirx/core';
import { IMatPaginationItem } from '../types/mat-pagination-item.type';
import { IReactiveMatPaginationItem } from '../types/reactive-mat-pagination-item.type';
import { buildMatPaginationItems, IBuildMatPaginationItemsOptions } from './build-mat-pagination-items';
import { clampPageIndex } from './clamp-page-index';

export interface IBuildMatPaginationParamsOptions extends Omit<IBuildMatPaginationItemsOptions, 'navigateToPage' | 'selectedPageIndex'> {
}

export interface IBuildMatPaginationParamsResult {
  paginationItems$: IObservable<readonly IReactiveMatPaginationItem[]>,
  selectedPageIndex$: IObservable<number>,
  $selectedPageIndex: IObserver<number>,
}

export function buildMatPaginationParams(
  options: IBuildMatPaginationParamsOptions,
): IBuildMatPaginationParamsResult {
  const [$paginationItems, paginationItems$] = let$$<IReactiveMatPaginationItem[]>();
  const [_$selectedPageIndex, selectedPageIndex$] = let$$<number>();

  const $selectedPageIndex = $$map(
    $$distinct(
      _$selectedPageIndex,
    ),
    (selectedPageIndex: number): number => {
      return clampPageIndex(selectedPageIndex, options.count);
    },
  );

  selectedPageIndex$((selectedPageIndex: number): void => {
    $paginationItems(
      buildMatPaginationItems({
        ...options,
        selectedPageIndex,
      }),
    );
  });

  $selectedPageIndex(0);

  return {
    paginationItems$,
    selectedPageIndex$,
    $selectedPageIndex,
  };
}

export function buildReactiveMatPaginationParams(
  options$: IObservable<IBuildMatPaginationParamsOptions>,
): IBuildMatPaginationParamsResult {
  const pagination$ = pipe$$(options$, [
    map$$$<IBuildMatPaginationParamsOptions, IBuildMatPaginationParamsResult>((options: IBuildMatPaginationParamsOptions): IBuildMatPaginationParamsResult => {
      return buildMatPaginationParams(options);
    }),
    shareRL$$$<IBuildMatPaginationParamsResult>(),
  ]);

  const paginationItems$ = switchMap$$(
    pagination$,
    ({ paginationItems$ }: IBuildMatPaginationParamsResult): IObservable<readonly IReactiveMatPaginationItem[]> => {
      return paginationItems$;
    },
  );

  const selectedPageIndex$ = switchMap$$(
    pagination$,
    ({ selectedPageIndex$ }: IBuildMatPaginationParamsResult): IObservable<number> => {
      return selectedPageIndex$;
    },
  );

  const [$selectedPageIndex] = mapObservableToObserver(
    pagination$,
    ({ $selectedPageIndex }: IBuildMatPaginationParamsResult): IObserver<number> => {
      return $selectedPageIndex;
    },
  );

  return {
    paginationItems$,
    selectedPageIndex$,
    $selectedPageIndex,
  };
}

