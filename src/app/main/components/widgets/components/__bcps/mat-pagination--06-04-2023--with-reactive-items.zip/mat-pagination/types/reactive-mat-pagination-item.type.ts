import { IObservableLike } from '@lirx/core';
import {
  IMatPaginationItemEllipsis,
  IMatPaginationItemFirst,
  IMatPaginationItemLast,
  IMatPaginationItemNext,
  IMatPaginationItemPage,
  IMatPaginationItemPrevious,
} from './mat-pagination-item.type';

export interface IReactiveMatPaginationItemButton {
  readonly pageIndex: IObservableLike<number>;
  readonly disabled: IObservableLike<boolean>;
}

export interface IReactiveMatPaginationItemFirst extends Pick<IMatPaginationItemFirst, 'type'> {
}

export interface IReactiveMatPaginationItemPrevious extends Pick<IMatPaginationItemPrevious, 'type'>, IReactiveMatPaginationItemButton {
}

export interface IReactiveMatPaginationItemPage extends Pick<IMatPaginationItemPage, 'type'>, IReactiveMatPaginationItemButton {
  readonly selected: IObservableLike<boolean>;
}

export interface IReactiveMatPaginationItemEllipsis extends Pick<IMatPaginationItemEllipsis, 'type'> {
}

export interface IReactiveMatPaginationItemNext extends Pick<IMatPaginationItemNext, 'type'>, IReactiveMatPaginationItemButton {
}

export interface IReactiveMatPaginationItemLast extends Pick<IMatPaginationItemLast, 'type'>, IReactiveMatPaginationItemButton {
}

export type IReactiveMatPaginationItem =
  | IReactiveMatPaginationItemFirst
  | IReactiveMatPaginationItemPrevious
  | IReactiveMatPaginationItemPage
  | IReactiveMatPaginationItemEllipsis
  | IReactiveMatPaginationItemNext
  | IReactiveMatPaginationItemLast
  ;
