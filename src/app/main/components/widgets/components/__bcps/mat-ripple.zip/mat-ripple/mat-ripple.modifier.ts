import { conditional$$, fromEventTarget, IObservable, single } from '@lirx/core';
import {
  compileStyleAsComponentStyle,
  createVirtualReactiveElementNodeModifier,
  getElementCSSVariableValueOrDefault,
  IGenericVirtualReactiveElementNode,
  querySelectorOrThrow,
  VirtualDOMNode, VirtualReactiveElementNode,
} from '@lirx/dom';
import { createRippleFromElementAndPointerEvent } from '@lirx/dom-material';

// @ts-ignore
import style from './mat-ripple.component.scss?inline';

const componentStyle = compileStyleAsComponentStyle(style);

export function matRippleModifierFunction(
  node: IGenericVirtualReactiveElementNode,
  enabled$: IObservable<boolean> = single(true),
): VirtualDOMNode {
  const element: HTMLElement = node.elementNode as HTMLElement;

  componentStyle(node);
  console.log('oki');

  const ripplesContainer = VirtualReactiveElementNode.createHTML<HTMLSpanElement>('span');
  const ripplesContainerElement: HTMLSpanElement = ripplesContainer.elementNode;
  ripplesContainerElement.classList.add('mat-ripple');
  // ripplesContainerElement.style.setProperty('position', 'absolute');
  // ripplesContainerElement.style.setProperty('inset', '0');
  // ripplesContainerElement.style.setProperty('pointer-events', 'none');
  // ripplesContainerElement.style.setProperty('pointer-events', 'none');

  node.attach(ripplesContainer);

  const onPointerDown = (event: PointerEvent): void => {
    if (event.button === 0) {
      const color: string = getElementCSSVariableValueOrDefault(element, '--mat-ripple-color', 'rgba(0, 0, 0, 0.1)');
      const openDuration: number = Number(getElementCSSVariableValueOrDefault(element, '--mat-ripple-open-duration', '200'));
      const closeDuration: number = Number(getElementCSSVariableValueOrDefault(element, '--mat-ripple-close-duration', '200'));

      const {
        element: rippleElement,
        open,
        close,
      } = createRippleFromElementAndPointerEvent({
        element,
        event,
        color,
        openDuration,
        closeDuration,
      });

      ripplesContainerElement.appendChild(rippleElement);

      const unsubscribePointerUp = pointerUp$(() => {
        unsubscribePointerUp();
        openPromise.then(() => {
          return close()
            .then(() => {
              rippleElement.remove();
            });
        });
      });

      const openPromise = open();
    }
  };

  const pointerDown$ = conditional$$(
    fromEventTarget<'pointerdown', PointerEvent>(element, 'pointerdown'),
    enabled$,
  );

  const pointerUp$ = fromEventTarget(window, 'pointerup');

  pointerDown$(onPointerDown);

  return node;
}

export const MAT_RIPPLE_MODIFIER = createVirtualReactiveElementNodeModifier<IObservable<boolean> | undefined, VirtualDOMNode>('mat-ripple', matRippleModifierFunction);


