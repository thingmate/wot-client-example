import { function$$, map$$ } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent, VirtualCustomElementNode } from '@lirx/dom';

// @ts-ignore
import html from './mat-link.component.html?raw';
// @ts-ignore
import style from './mat-link.component.scss?inline';

/**
 * COMPONENT: 'mat-link'
 **/

interface IMatLinkComponentConfig {
  element: HTMLElement;
  inputs: [
    ['disabled', boolean],
    ['href', string],
  ];
}

export const MatLinkComponent = createComponent<IMatLinkComponentConfig>({
  name: 'mat-link',
  extends: 'a',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['disabled'],
    ['href'],
  ],
  init: (node: VirtualCustomElementNode<IMatLinkComponentConfig>): void => {
    /* DISABLED */

    const disabled$ = node.inputs.get$('disabled');

    node.setReactiveClass('mat-disabled', disabled$);

    /* HREF */
    const _href$ = node.inputs.get$('href');

    const href$ = function$$(
      [_href$, disabled$],
      (href: string, disabled: boolean): string => {
        return (disabled || (href.trim() === ''))
          ? `javascript:`
          : href;
      },
    );
    node.setReactiveProperty('href', href$);

    /* TAB-INDEX */

    const tabIndex$ = map$$(disabled$, (disabled: boolean): number => {
      return disabled
        ? -1
        : 0;
    });

    node.setReactiveProperty('tabIndex', tabIndex$);
  },
});

