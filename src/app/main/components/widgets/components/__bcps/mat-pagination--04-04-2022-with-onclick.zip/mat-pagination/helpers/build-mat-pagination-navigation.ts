import { Abortable, AsyncTask, IAsyncTaskInput } from '@lirx/async-task';
import { IObservable, let$$ } from '@lirx/core';
import { IMatPaginationItem } from '../mat-pagination-item.type';
import { buildMatPaginationItems, IBuildMatPaginationItemsOptions } from './build-mat-pagination-items';
import { INavigateToPageFunction, MatPaginationNavigation } from './mat-pagination-navigation.class';

export type IBuildMatPaginationNavigationObPageChangeFunction = INavigateToPageFunction;

export interface IBuildMatPaginationNavigationOptions extends Omit<IBuildMatPaginationItemsOptions, 'navigateToPage' | 'selectedPageIndex'> {
  onPageChange: IBuildMatPaginationNavigationObPageChangeFunction;
}

export type IBuildMatPaginationNavigationResult = [
  item$: IObservable<readonly IMatPaginationItem[]>,
  navigation: MatPaginationNavigation,
];

export function buildMatPaginationNavigation(
  {
    onPageChange,
    ...options
  }: IBuildMatPaginationNavigationOptions,
): IBuildMatPaginationNavigationResult {
  const [$items, items$] = let$$<IMatPaginationItem[]>();

  const navigation = new MatPaginationNavigation(
    (
      selectedPageIndex: number,
      abortable: Abortable,
    ): AsyncTask<void> => {
      return AsyncTask.fromFactory(
        (abortable: Abortable): IAsyncTaskInput<void> => {
          return onPageChange(selectedPageIndex, abortable);
        },
        abortable,
      )
        .successful(() => {
          const items: IMatPaginationItem[] = buildMatPaginationItems({
            ...options,
            selectedPageIndex,
            navigateToPage: (index: number): void => {
              navigation.navigateToPage(index, Abortable.never);
            },
          });

          $items(items);
        });
    },
    options.count,
  );

  return [
    items$,
    navigation,
  ];
}
