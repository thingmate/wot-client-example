import { IObservable } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { MAT_BUTTON_MODIFIER, MAT_ICON_BUTTON_MODIFIER } from '@lirx/dom-material';
import { IconChevronLeftComponent, IconChevronRightComponent, IconPageFirstComponent, IconPageLastComponent } from '@lirx/mdi';
import { IMatPaginationItem } from './mat-pagination-item.type';

// @ts-ignore
import html from './mat-pagination.component.html?raw';
// @ts-ignore
import style from './mat-pagination.component.scss?inline';

/** TYPES **/

/**
 * COMPONENT: 'mat-pagination'
 **/

interface IData {
  readonly items$: IObservable<readonly IMatPaginationItem[]>;
}

interface IMatPaginationComponentConfig {
  element: HTMLElement;
  inputs: [
    ['items', readonly IMatPaginationItem[]],
    ['disabled', boolean],
  ];
  data: IData;
}

export const MatPaginationComponent = createComponent<IMatPaginationComponentConfig>({
  name: 'mat-pagination',
  extends: 'nav',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      IconPageFirstComponent,
      IconChevronLeftComponent,
      IconChevronRightComponent,
      IconPageLastComponent,
    ],
    modifiers: [
      MAT_BUTTON_MODIFIER,
      MAT_ICON_BUTTON_MODIFIER,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    ['items'],
    ['disabled', false],
  ],
  init: (node: VirtualCustomElementNode<IMatPaginationComponentConfig>): IData => {
    node.setAttribute('aria-label', 'pagination navigation');

    /* ITEMS */
    const items$ = node.inputs.get$('items');

    /* DISABLED */

    const disabled$ = node.inputs.get$('disabled');

    node.setReactiveClass('mat-disabled', disabled$);

    return {
      items$,
    };
  },
});
