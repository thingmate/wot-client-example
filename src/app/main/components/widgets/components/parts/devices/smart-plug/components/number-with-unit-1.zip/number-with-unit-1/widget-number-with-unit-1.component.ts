import { Abortable, AsyncTask } from '@lirx/async-task';
import { IObservable, let$$ } from '@lirx/core';
import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent, VirtualCustomElementNode } from '@lirx/dom';
import { sleep } from '@lirx/promise';
import { createConsumedThingFromWoT, fetchTD, IConsumedThing, ISmartPlugConfig, IWoT } from '@thingmate/wot-scripting-api';
import { ThingDescription } from 'wot-typescript-definitions';
import { runWoTContext } from '../../../../../../../../../wot/run-wot-context';
import { WidgetNumberWithUnitComponent } from '../../widget-number-with-unit.component';

// @ts-ignore
import html from './widget-number-with-unit-1.component.html?raw';
// @ts-ignore
import style from './widget-number-with-unit-1.component.scss?inline';


/**
 * COMPONENT: 'app-widget-number-with-unit-1'
 **/

interface IData {
  readonly power$: IObservable<number>;
}

interface IWidgetNumberWithUnit1ComponentConfig {
  element: HTMLElement;
  data: IData;
}

export type ISmartPlug = IConsumedThing<ISmartPlugConfig>;

export const WidgetNumberWithUnit1Component = createComponent<IWidgetNumberWithUnit1ComponentConfig>({
  name: 'app-widget-number-with-unit-1',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      WidgetNumberWithUnitComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  init: (node: VirtualCustomElementNode<IWidgetNumberWithUnit1ComponentConfig>): IData => {
    const [$power, power$] = let$$<number>();

    let thing: ISmartPlug;

    const getConsumedThing = () => {
      return runWoTContext((WoT: IWoT) => {
        return fetchTD('http://localhost:8080/19011048496979251h0234298f149604', void 0, Abortable.never)
          .successful((td: ThingDescription, abortable: Abortable): AsyncTask<ISmartPlug> => {
            return createConsumedThingFromWoT(WoT, td, { abortable });
          })
          .toPromise();
      });
    };

    getConsumedThing()
      .then((_thing: ISmartPlug): void => {
        thing = _thing;

        const propertyState = thing.getProperty('consumption');

        const loop = async () => {
          while (true) {
            $power((await propertyState.read()).power);
            await sleep(1000);
          }
        };

        loop();
      });

    return {
      power$,
    };
  },
});
