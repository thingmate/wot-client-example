import { compileReactiveHTMLAsComponentTemplate, compileStyleAsComponentStyle, createComponent } from '@lirx/dom';
import { MatIconButtonComponent } from '@lirx/dom-material';
import { IconDotsVerticalComponent, IconDragVerticalComponent } from '@lirx/mdi';

// @ts-ignore
import html from './widget.component.html?raw';
// @ts-ignore
import style from './widget.component.scss?inline';

/**
 * COMPONENT: 'app-widget'
 **/

interface IData {
}

interface IWidgetComponentConfig {
  element: HTMLElement;
  data: IData;
}

export const WidgetComponent = createComponent<IWidgetComponentConfig>({
  name: 'app-widget',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatIconButtonComponent,
      IconDragVerticalComponent,
      IconDotsVerticalComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  init: (): IData => {
    return {};
  },
});
